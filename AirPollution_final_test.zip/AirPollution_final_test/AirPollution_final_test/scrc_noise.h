/*
 * scrc_noise.h
 *
 *  Created on: 16-Oct-2020
 *      Author: BSRC-Sam
 */

#ifndef INCLUDE_SCRC_NOISE_H_
#define INCLUDE_SCRC_NOISE_H_

void hw_setup_noise();
void hw_read_noise(short int *buf_noise);

#endif /* INCLUDE_SCRC_NOISE_H_ */
