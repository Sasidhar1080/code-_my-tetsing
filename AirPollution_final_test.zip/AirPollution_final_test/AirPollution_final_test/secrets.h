#define SECRET_SSID "TP-Link_0EC8"    // replace MySSID with your WiFi network name
#define SECRET_PASS "78726598"  // replace MyPassword with your WiFi password

#define SECRET_CH_ID 939888     // replace 0000000 with your channel number
#define SECRET_WRITE_APIKEY "WDVVTDSX00XL5V05"   // replace XYZ with your channel write API Key
