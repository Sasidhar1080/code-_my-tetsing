/*
 * scrc_so2.h
 *
 *  Created on: 16-Oct-2020
 *      Author: BSRC-Sam
 */

#ifndef INCLUDE_SCRC_SO2_H_
#define INCLUDE_SCRC_SO2_H_

void hw_setup_so2();
void hw_read_so2(float *buf);

#endif /* INCLUDE_SCRC_SO2_H_ */
