/*
 * scrc_co2.h
 *
 *  Created on: 16-Oct-2020
 *      Author: BSRC-Sam
 */

#ifndef INCLUDE_SCRC_CO2_H_
#define INCLUDE_SCRC_CO2_H_

void hw_setup_co2();
void hw_read_co2(float *buf_co2);

#endif /* INCLUDE_SCRC_CO2_H_ */
